---
name: Clinical Precision
colors:
  surface: '#f6faf9'
  surface-dim: '#d7dbda'
  surface-bright: '#f6faf9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f3'
  surface-container: '#ebefee'
  surface-container-high: '#e5e9e8'
  surface-container-highest: '#dfe3e2'
  on-surface: '#181c1c'
  on-surface-variant: '#3e4948'
  inverse-surface: '#2d3131'
  inverse-on-surface: '#eef1f0'
  outline: '#6e7979'
  outline-variant: '#bdc9c8'
  surface-tint: '#006a69'
  primary: '#006161'
  on-primary: '#ffffff'
  primary-container: '#0e7c7b'
  on-primary-container: '#c3fffd'
  inverse-primary: '#7cd5d3'
  secondary: '#00658c'
  on-secondary: '#ffffff'
  secondary-container: '#67c8fe'
  on-secondary-container: '#005373'
  tertiary: '#00625c'
  on-tertiary: '#ffffff'
  tertiary-container: '#2a7b75'
  on-tertiary-container: '#c5fff8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#98f2f0'
  primary-fixed-dim: '#7cd5d3'
  on-primary-fixed: '#002020'
  on-primary-fixed-variant: '#00504f'
  secondary-fixed: '#c5e7ff'
  secondary-fixed-dim: '#80d0ff'
  on-secondary-fixed: '#001e2d'
  on-secondary-fixed-variant: '#004c6a'
  tertiary-fixed: '#a4f0e9'
  tertiary-fixed-dim: '#88d4cd'
  on-tertiary-fixed: '#00201e'
  on-tertiary-fixed-variant: '#00504b'
  background: '#f6faf9'
  on-background: '#181c1c'
  surface-variant: '#dfe3e2'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.5'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  sidebar_width: 240px
  topbar_height: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style
This design system is engineered for the high-stakes environment of community healthcare administration. It prioritizes clarity, speed of cognition, and accessibility above all else. The style is **Corporate/Modern**, utilizing a structured grid and a high-contrast palette to ensure that clinical data is legible under various lighting conditions in a medical facility.

The emotional response should be one of **calm authority and reliability**. By balancing professional slate neutrals with a life-affirming teal and mint palette, the UI feels clean and hygienic without being sterile or intimidating. Every interaction is designed to minimize cognitive load for administrators and healthcare providers.

## Colors
The palette is rooted in a **Slate Neutral** foundation to provide a sophisticated, professional backdrop. 

- **Primary Teal (#0E7C7B):** Used for primary actions, active navigation states, and the "Calling" status to represent health and focus.
- **Secondary Blue (#3DA5D9):** Used for informational elements, secondary buttons, and data visualization.
- **Accent Mint (#73BFB8):** Applied sparingly for subtle highlights and decorative elements that need to feel fresh.
- **Status Colors:** These are strictly reserved for patient queue management. The "Calling" state should be paired with a subtle pulse animation using the primary teal.

## Typography
The system uses **Inter** as the primary workhorse font for its exceptional legibility in data-heavy interfaces. **Plus Jakarta Sans** is utilized for labels and UI controls to provide a slightly friendlier, modern touch to the functional elements.

Hierarchies are strictly enforced to guide the eye through complex patient records. Body text defaults to `body-md` for optimal readability, while `label-sm` is used for non-editable metadata and table headers.

## Layout & Spacing
The layout follows a **Fixed Sidebar** model for constant access to navigation, paired with a persistent **Top Bar** for search and global actions.

- **Sidebar:** 240px fixed width, utilizing a dark or high-contrast teal variant for clear separation from the content area.
- **Main Content:** A fluid area that uses a 12-column grid on desktop. 
- **Rhythm:** An 8px base unit governs all spacing. Vertical stacks within cards should use `stack-md` (16px) for standard grouping and `stack-sm` (8px) for tightly coupled information like a label and its input.

## Elevation & Depth
Depth is used functionally to separate the "workspace" (the background) from "active tasks" (the cards).

- **Tonal Layers:** The background uses Slate-100 (#F1F5F9). Cards sit on top of this in pure White (#FFFFFF).
- **Subtle Card Shadow:** Applied to all standard data containers. Use a soft, low-opacity shadow (e.g., `0px 2px 4px rgba(15, 23, 42, 0.05)`).
- **Pronounced Elevated Shadow:** Used for modals, dropdowns, and active patient cards in the queue. This shadow should be more diffused to suggest physical proximity to the user (e.g., `0px 12px 24px rgba(15, 23, 42, 0.1)`).
- **Borders:** Use a 1px Slate-200 border for all cards to maintain high-contrast definition even when shadows are subtle.

## Shapes
The shape language is "Rounded," balancing professional structure with approachable softness. 

- **Small (6px):** Used for interactive controls like checkboxes, radio buttons, and small action buttons.
- **Medium (12px):** The standard for input fields, buttons, and inner nested containers.
- **Large (20px):** Reserved for primary dashboard cards and the main container of the clinical workspace.

## Components
- **Buttons:** Primary buttons use the Teal #0E7C7B with white text. Secondary buttons use a Slate-100 background with Teal text. All buttons use `radius-md`.
- **Status Chips:** Used for the queue. They feature a light tinted background of the status color with high-contrast bold text of the same hue (e.g., Done uses a light green background with Dark Green text).
- **Input Fields:** Use a 1px Slate-300 border that thickens and changes to Teal on focus. Labels sit clearly above the field using `label-md`.
- **Data Tables:** High-density with subtle horizontal dividers only. Row hovering should use a very light Mint tint (#F0F9F8) to highlight the active record.
- **Sidebar Nav:** Icons should be simple, 24px stroke-based. The active state uses a vertical teal bar on the left edge and a subtle text weight increase.
- **Alerts/Toasts:** Positioned top-right, using the status colors for instant recognition of system feedback (Success, Warning, Error).